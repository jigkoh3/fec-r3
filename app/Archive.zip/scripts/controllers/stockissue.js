angular.module('fec3App')
    .controller('stockissueCtrl', function($scope) {

         $scope.ordersummary = [{
         	imageno: "icon_no",
            promotion: "1. 3000036063 iPhone 6 Plus,16GB,Gold",
            count: "1",
            serial: "xxxxxxxxxxxxxxx"
          }, {
          	imageno: "icon_no",
            promotion: "2. 3000036063 SIM CARD",
            count: "1",
            serial: "896604345654323456"
          }, {
          	imageno: "icon_no",
            promotion: "3. 3000023456 Accessory",
            count: "1",
            }];

    	});
